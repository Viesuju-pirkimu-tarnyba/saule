Tai � trumpas EBVPD rinkmen�, kurias rasite �iame ZIP aplanke, apra�ymas.

espd.XML: XML rinkmena � tai m�s� EBVPD paslaugoms arba kitoms su EBVPD suderinamoms paslaugoms suprantama rinkmena. Naudojimosi e. EBVPD kaip XML rinkmenos prana�umas yra tai, kad pirk�jai ir bendrov�s gal�s j� panaudoti kitoms proced�roms ateityje. Ji tur�t� b�ti siun�iama kartu su vie��j� pirkim� dokumentais (organizacija bendrovei) arba kaip pasi�lymo dalis (bendrov� organizacijai).

espd.PDF: PDF rinkmena � tai �mon�ms suprantama e. EBVPD rinkmena. Taip pat si�lome naudoti  j� kaip informacin� dokument� kartu su XML formatu teikiant vie��j� pirkim� dokumentus (organizacija bendrovei) arba kaip pasi�lymo dal� (bendrov� organizacijai).

Jei turite klausim� apie rinkmenas, nedvejodami susisiekite su mumis �iuo e. pa�to adresu: pagalba@vpt.lt.