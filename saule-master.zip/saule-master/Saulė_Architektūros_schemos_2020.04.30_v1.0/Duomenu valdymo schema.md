![Duomenu valdymo schema](https://user-images.githubusercontent.com/61745726/82418103-3c3a4100-9a85-11ea-9165-09cfbe70dddb.jpg)
