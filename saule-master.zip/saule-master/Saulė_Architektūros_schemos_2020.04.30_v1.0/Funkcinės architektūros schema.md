![Funkcinės architektūros schema](https://user-images.githubusercontent.com/61745726/82418108-3e9c9b00-9a85-11ea-946a-24e6d267e2d3.jpg)
