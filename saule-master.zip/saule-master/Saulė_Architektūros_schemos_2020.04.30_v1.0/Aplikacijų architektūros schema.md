![Aplikacijų architektūros schema](https://user-images.githubusercontent.com/61745726/82418055-29c00780-9a85-11ea-8205-5857707bc881.jpg)
