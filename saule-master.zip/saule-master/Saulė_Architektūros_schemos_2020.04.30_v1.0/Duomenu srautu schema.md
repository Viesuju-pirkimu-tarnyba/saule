![Duomenu srautu schema](https://user-images.githubusercontent.com/61745726/82418096-3a707d80-9a85-11ea-891f-674c00be7908.jpg)
