![Diegimo technologines architektūros schema](https://user-images.githubusercontent.com/61745726/82418062-2dec2500-9a85-11ea-9353-6aa4046bea13.jpg)
