![Integracinių sąsajų schema](https://user-images.githubusercontent.com/61745726/82418119-41978b80-9a85-11ea-887f-29cf617db748.jpg)
